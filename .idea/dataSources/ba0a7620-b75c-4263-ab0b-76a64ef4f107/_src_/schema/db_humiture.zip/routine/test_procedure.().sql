CREATE PROCEDURE test_procedure()
  BEGIN
    INSERT INTO test (value) VALUES ('111');
  END;
